<template>
  <div class="login-page">
    <q-page-container class="page-container">
      <q-page>
        <q-card>
          <q-card-section>
            <div class="avatar-container">
              <q-avatar class="custom-avatar" size="lg">
                <img src="../assets/user-avatar.png" alt="Avatar" />
              </q-avatar>
            </div>
          </q-card-section>

          <q-card-section>
            <q-input filled v-model="username" label="Username" />

            <q-input
              filled
              v-model="password"
              label="Password"
              :type="isPwd ? 'password' : 'text'"
            >
              <template v-slot:append>
                <q-icon
                  :name="isPwd ? 'visibility_off' : 'visibility'"
                  class="cursor-pointer"
                  @click="isPwd = !isPwd"
                />
              </template>
            </q-input>

            <div class="button-container">
              <q-btn color="primary" label="Login" @click="login" />
              <q-btn
                color="primary"
                label="Register"
                @click="openRegistrationForm"
              />
            </div>
          </q-card-section>
        </q-card>
      </q-page>
    </q-page-container>

    <q-dialog v-model="registrationDialog" persistent>
      <q-card>
        <q-card-section>
          <q-form @submit="registerUser">
            <q-input
              filled
              v-model="newUser.username"
              label="Username"
              :rules="[(val) => !!val || 'Field is required']"
            />
            <q-input
              filled
              v-model="newUser.password"
              label="Password"
              :type="isPwd ? 'password' : 'text'"
              :rules="[(val) => !!val || 'Field is required']"
            >
              <template v-slot:append>
                <q-icon
                  :name="isPwd ? 'visibility_off' : 'visibility'"
                  class="cursor-pointer"
                  @click="isPwd = !isPwd"
                />
              </template>
            </q-input>
            <q-input
              filled
              v-model="newUser.email"
              label="Email"
              type="email"
              :rules="[(val) => !!val || 'Email is missing', isValidEmail]"
            />
            <q-input
              filled
              v-model="newUser.telefone"
              label="Telefone"
              mask="phone"
              type="tel"
            />
            <div class="button-container">
              <q-btn color="primary" label="Register" type="submit" />
              <q-btn
                color="primary"
                label="Cancel"
                @click="closeRegistrationForm"
              />
            </div>
          </q-form>
        </q-card-section>
      </q-card>
    </q-dialog>
  </div>
</template>

<script>
import { useQuasar } from "quasar";
import { ref } from "vue";
import Services from "src/services";
import { appStore } from "src/stores/appStore";
import { defineComponent } from "vue";
import { useRouter } from "vue-router";

export default defineComponent({
  setup() {
    const $router = useRouter();
    const $q = useQuasar();
    const username = ref("");
    const password = ref("");
    const newUser = ref({
      username: "",
      password: "",
      email: "",
      telefone: "",
    });
    const registrationDialog = ref(false);

    const openRegistrationForm = () => {
      registrationDialog.value = true;
    };

    const closeRegistrationForm = () => {
      registrationDialog.value = false;
      newUser.value.username = "";
      newUser.value.password = "";
      newUser.value.email = "";
      newUser.value.telefone = "";
    };

    const registerUser = async () => {
      // Gravar os dados do novo cliente no arquivo banco.json
      try {
        await Services.saveCliente(newUser.value, (success) => {
          if (success) {
            $q.notify({
              type: "positive",
              message: "Registration successful!",
            });
            closeRegistrationForm();
          } else {
            $q.notify({
              type: "negative",
              message: "Error registering client.",
            });
          }
        });
      } catch (error) {
        $q.notify({
          type: "negative",
          message: "Error registering client.",
        });
      }
    };

    const login = async () => {
      // Verificar se o cliente e a senha existem no arquivo banco.json
      try {
        const isAuthenticated = await Services.authenticateCliente(
          username.value,
          password.value
        );
        if (isAuthenticated) {
          // Cliente autenticado com sucesso
          appStore.cliente = {
            nome: "",
            email: "",
          };

          $q.notify({
            type: "positive",
            message: "Login correto",
          });
          $router.push("/main");
        } else {
          // Credenciais inválidas
          $q.notify({
            type: "negative",
            message: "Invalid username or password.",
          });
        }
      } catch (error) {
        $q.notify({
          type: "negative",
          message: "Error authenticating client.",
        });
      }
    };

    return {
      username,
      password,
      isPwd: ref(true),
      email: "",
      newUser,
      registrationDialog,
      openRegistrationForm,
      closeRegistrationForm,
      registerUser,
      login,
    };
  },

  methods: {
    isValidEmail(val) {
      const emailPattern =
        /^(?=[a-zA-Z0-9@._%+-]{6,254}$)[a-zA-Z0-9._%+-]{1,64}@(?:[a-zA-Z0-9-]{1,63}\.){1,8}[a-zA-Z]{2,63}$/;
      return emailPattern.test(val) || "Invalid email";
    },
  },
});
</script>

<style scoped>
.login-page {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  overflow: hidden; /* Oculta a barra de rolagem vertical */
}

.page-container {
  height: 100%; /* Define a altura máxima do contêiner */
  display: flex;
  flex-direction: column;
}

.page-container > * {
  flex: 0 0 auto; /* Mantém a altura fixa dos elementos filhos */
}

.login-page .q-card {
  max-width: 400px;
  padding: 20px;
  width: 100%;
}

.avatar-container {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.custom-avatar {
  width: 120px !important;
  height: 120px !important;
}

.button-container {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}
</style>
