<template>
  <q-layout view="hHh lpR fFf">
    <q-header elevated>
      <q-toolbar>
        <q-toolbar-title>UNILOCADORA</q-toolbar-title>
        <div class="q-toolbar__side">
          <q-icon
            name="shopping_cart"
            class="cursor-pointer"
            @click="mostrarCarrinho"
            size="25px"
          />
          <q-icon
            name="delete"
            class="cursor-pointer"
            @click="limparCarrinho"
            size="25px"
          />
        </div>
        <div class="q-pa-md">
          <q-input
            v-model="busca"
            label="Buscar filmes"
            outlined
            dense
            class="search-input"
            style="max-width: 600px; height: 40px"
            bg-color="secondary"
          />
        </div>
      </q-toolbar>
    </q-header>

    <q-page-container>
      <div class="filmes-container">
        <div
          class="filme-card"
          v-for="filme in filmesFiltrados"
          :key="filme.id"
        >
          <FilmeCard
            :filme="filme"
            @locarFilme="onLocarFilme"
            @devolverFilme="onDevolverFilme"
          />
        </div>
      </div>
    </q-page-container>
  </q-layout>
</template>

<script>
import { useQuasar } from "quasar";
import Services from "src/services";
import { appStore } from "src/stores/appStore";
import { defineComponent } from "vue";
import FilmeCard from "../components/FilmeCard.vue";

export default defineComponent({
  components: { FilmeCard },
  name: "IndexPage",
  data() {
    return {
      filmes: [],
      busca: "",
      mostrarListaFilmes: false,
    };
  },
  created() {
    Services.getAllFilmes((data) => {
      this.filmes = data;
    });
    this.filmes.forEach((filme) => {
      filme.indisponivel = false; // Define inicialmente todos os filmes como disponíveis
    });
  },
  computed: {
    filmesPorGenero() {
      const filmesFiltrados = this.filtrarFilmes();
      const filmesPorGenero = {};

      for (const filme of filmesFiltrados) {
        if (!filmesPorGenero[filme.genero]) {
          filmesPorGenero[filme.genero] = [];
        }
        filmesPorGenero[filme.genero].push(filme);
      }

      return filmesPorGenero;
    },

    filmesFiltrados() {
      const termoBusca = this.busca.toLowerCase().trim();
      if (termoBusca === "") {
        return this.filmes;
      }

      return this.filmes.filter((filme) => {
        return (
          filme.genero.toLowerCase().includes(termoBusca) ||
          filme.titulo.toLowerCase().includes(termoBusca) ||
          filme.diretor.toLowerCase().includes(termoBusca) ||
          filme.ano.toString().includes(termoBusca) ||
          filme.atores.some((ator) => ator.toLowerCase().includes(termoBusca))
        );
      });
    },
  },
  methods: {
    mostrarCarrinho() {
      if (appStore.carrinho.filmes.length === 0) {
        console.log("Carrinho vazio");
      } else {
        this.$q.dialog({
          title: "Carrinho de Filmes",
          message:
            "<ul>" +
            appStore.carrinho.filmes
              .map((filme) => `<li>${filme.titulo}</li>`)
              .join("") +
            "</ul>",
          html: true,
          persistent: true,
        });
      }
    },
    limparCarrinho() {
      appStore.limparCarrinho();
    },

    onLocarFilme(filme) {
      appStore.addFilmeCarrinho(filme);
      appStore.setClienteCarrinho(appStore.cliente);
      filme.indisponivel = true;
    },

    onDevolverFilme(filme) {
      appStore.removeFilmeCarrinho(filme);
      filme.indisponivel = false;
    },
  },
});
</script>

<style scoped>
.filmes-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding: 16px;
}

.filme-card {
  width: calc(25% - 32px);
  margin: 16px;
}

.search-input {
  margin: 0 auto;
}

.carrinho-dialog {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}
</style>
