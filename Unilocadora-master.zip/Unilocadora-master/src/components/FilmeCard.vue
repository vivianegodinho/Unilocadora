<template>
  <q-card
    :class="{ indisponivel: isFilmeIndisponivel }"
    class="my-card bg-secondary text-white"
    :style="{
      backgroundImage: isFilmeIndisponivel
        ? 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5))'
        : '',
    }"
  >
    <q-card-section>
      <div class="text-h6">{{ filme.titulo }}</div>
      <div class="text-subtitle2">{{ filme.genero }}</div>
      <img :src="filme.poster" alt="Poster do filme" class="poster-img" />
    </q-card-section>

    <q-card-section>
      <ul>
        <li v-for="ator in filme.atores" v-bind:key="ator">{{ ator }}</li>
      </ul>
    </q-card-section>
    <q-card-section>
      Diretor: {{ filme.diretor }}<br />
      Ano: {{ filme.ano }}
    </q-card-section>
    <q-separator dark />

    <q-card-actions>
      <q-btn flat @click="locar">Locar</q-btn>
      <q-btn flat @click="devolver" v-if="isFilmeIndisponivel">Devolver</q-btn>
    </q-card-actions>
  </q-card>
</template>

<script>
export default {
  props: {
    filme: Object,
    isFilmeDisabled: Boolean,
  },
  methods: {
    locar() {
      if (!this.filme.indisponivel) {
        this.$emit("locarFilme", this.filme);
      }
    },
    devolver() {
      this.$emit("devolverFilme", this.filme);
    },
  },
  computed: {
    isFilmeIndisponivel() {
      return this.filme.indisponivel;
    },
  },
};
</script>

<style>
.poster-img {
  width: 100%;
  height: 400px;
}

.indisponivel {
  filter: grayscale(100%);
}
</style>
