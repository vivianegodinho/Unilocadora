import { defineStore } from "pinia";
const useAppStore = defineStore("app", {
  state: () => ({
    carrinho: {
      filmes: [],
      cliente: null,
      valor: 0,
      data: null,
      devolvido: false,
    },
    cliente: null,
    filmes: [],
  }),
  actions: {
    addFilme(filme) {
      this.filmes.push(filme);
    },
    setFilmes(filmes) {
      this.filmes = filmes;
    },
    getFilmesByAno(ano) {
      return this.filmes.filter((filme) => filme.ano == ano);
    },
    getFilmesByActor(actor) {
      return this.filmes.filter((filme) => filme.atores.includes(actor));
    },
    setCliente(cliente) {
      this.cliente = cliente;
    },
    limparCarrinho() {
      this.carrinho = {
        filmes: [],
        cliente: null,
        valor: 0,
        data: null,
        devolvido: false,
      };
      this.saveCarrinho();
    },
    setClienteCarrinho(cliente) {
      this.carrinho.cliente = cliente;
      this.saveCarrinho();
    },
    addFilmeCarrinho(filme) {
      this.carrinho.filmes.push(filme);
      this.saveCarrinho();
    },
    removeFilmeCarrinho(filme) {
      const index = this.carrinho.filmes.findIndex((f) => f.id === filme.id);
      if (index !== -1) {
        this.carrinho.filmes.splice(index, 1);
        this.saveCarrinho();
      }
    },

    loadCarrinho() {
      const carrinhoData = localStorage.getItem("carrinho");
      if (carrinhoData) {
        this.carrinho = JSON.parse(carrinhoData);
      }
    },

    saveCarrinho() {
      localStorage.setItem("carrinho", JSON.stringify(this.carrinho));
    },
  },
});
export const appStore = useAppStore();
appStore.loadCarrinho();
